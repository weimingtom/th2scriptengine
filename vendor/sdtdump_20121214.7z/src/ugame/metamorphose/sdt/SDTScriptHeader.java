package ugame.metamorphose.sdt;
public class SDTScriptHeader {
    public final static int SCRIPT_BLOCK_MAX = 256;

    public short h1; // 2 bytes
    public short h2; // 2 bytes
    public int Fsize; // 4 bytes
    public byte[] BlockAddres = new byte[SCRIPT_BLOCK_MAX * 4];

    @Override
    public String toString() {
	StringBuilder str = new StringBuilder();
	str.append("SDTScriptHeader = {");
	str.append("\n\th1 = ");
	str.append(h1);
	str.append("\n\th2 = ");
	str.append(h2);
	str.append("\n\tFsize = ");
	str.append(Fsize);
	str.append("\n}\n");
	return str.toString();
    }
}
