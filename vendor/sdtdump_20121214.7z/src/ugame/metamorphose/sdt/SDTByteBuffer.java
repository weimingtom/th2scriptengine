package ugame.metamorphose.sdt;
/**
 * @see Apache SSHD
 */
public class SDTByteBuffer {
    transient private byte[] data;
    transient private int rpos;
    transient private int wpos;

    /**
     * 
     * @param data
     */
    public SDTByteBuffer(final byte[] data) {
	this.data = data;
	this.rpos = 0;
	this.wpos = data.length;
    }

    /**
     * 
     * @return
     */
    public int getRpos() {
	return rpos;
    }

    /**
     * 
     * @param rpos
     */
    public void setRpos(final int rpos) {
	this.rpos = rpos;
    }

    /**
     * 
     * @return
     */
    public int available() {
	return wpos - rpos;
    }

    /**
     * 
     * @return
     * @throws SDTByteBufferException
     */
    public byte getByte() throws SDTByteBufferException {
	ensureAvailable(1);
	return data[rpos++];
    }

    /**
     * 
     * @return
     * @throws SDTByteBufferException
     */
    public short getShort() throws SDTByteBufferException {
	// return (short)getUShort();
	ensureAvailable(2);
	return (short) (((data[rpos++]) & 0x00ff) | ((data[rpos++] << 8) & 0xff00));
    }

    /**
     * 
     * @return
     * @throws SDTByteBufferException
     */
    public int getInt() throws SDTByteBufferException {
	// return (int) getUInt();
	ensureAvailable(4);
	return (int) (((data[rpos++]) & 0x000000ffL)
		| ((data[rpos++] << 8) & 0x0000ff00L)
		| ((data[rpos++] << 16) & 0x00ff0000L) | ((data[rpos++] << 24) & 0xff000000L));
    }

    /**
     * 
     * @param buf
     * @throws SDTByteBufferException
     */
    public void getRawBytes(final byte[] buf) throws SDTByteBufferException {
	ensureAvailable(buf.length);
	System.arraycopy(data, rpos, buf, 0, buf.length);
	rpos += buf.length;
    }

    /**
     * 
     * @param length
     * @throws SDTByteBufferException
     */
    private void ensureAvailable(final int length)
	    throws SDTByteBufferException {
	if (available() < length) {
	    throw new SDTByteBufferException("Underflow");
	}
    }
}
