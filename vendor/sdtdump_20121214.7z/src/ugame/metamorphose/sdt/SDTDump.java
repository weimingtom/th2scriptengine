package ugame.metamorphose.sdt;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

public class SDTDump {
    private static final String VERSION = "SDTDump ver 0.0.1".intern();
    private static final String SEPARATOR = "===============".intern();

    private static final boolean APPEND_FILE_HEADER = true;
    private static final boolean APPEND_ALL_FILE_DUMP = false;
    private static final boolean APPEND_SCRIPT_INFO = true;
    private static final boolean APPEND_SCRIPT_COMMAND = true;

    private static long LOOP_COUNT_LIMIT = 4000;

    /**
     * 
     * @param input
     * @param output
     * @throws IOException
     * @throws SDTByteBufferException
     */
    public void process(InputStream input, Writer output,
	    int[] command_count_table) throws IOException,
	    SDTByteBufferException {
	// StringBuilder不是线程安全，但比StringBuffer稍快
	// StringBuffer是线程安全
	StringBuilder content = new StringBuilder();

	byte[] input_bytes = new byte[input.available()];
	input.read(input_bytes);
	SDTByteBuffer buffer = new SDTByteBuffer(input_bytes);
	SDTScriptHeader header = new SDTScriptHeader();

	if (APPEND_FILE_HEADER) {
	    content.append(SDTDump.VERSION);
	    content.append('\n');

	    content.append(SDTDump.SEPARATOR);
	    content.append('\n');
	}

	if (APPEND_ALL_FILE_DUMP) {
	    content.append(SDTDumpUtils.getHexString(input_bytes, 0,
		    input_bytes.length));

	    content.append(SDTDump.SEPARATOR);
	    content.append('\n');
	}

	if (APPEND_SCRIPT_INFO) {
	    content.append("SDTConsts.ESC_VALUES.length == ");
	    content.append(SDTConsts.ESC_VALUES.length);
	    content.append('\n');

	    content.append("SDTConsts.ESC_NAMES.length == ");
	    content.append(SDTConsts.ESC_NAMES.length);
	    content.append('\n');

	    content.append("SDTConsts.ESC_OPRS.length == ");
	    content.append(SDTConsts.ESC_OPRS.length);
	    content.append('\n');

	    content.append("input_bytes.length == ");
	    content.append(input_bytes.length);
	    content.append('\n');

	    header.h1 = buffer.getShort();
	    header.h2 = buffer.getShort();
	    header.Fsize = buffer.getInt();
	    buffer.getRawBytes(header.BlockAddres);
	    content.append(header.toString());

	    content.append("buffer.getRpos() == ");
	    content.append(buffer.getRpos());
	    content.append('\n');

	    content.append(SDTDump.SEPARATOR);
	    content.append('\n');
	}

	if (APPEND_SCRIPT_COMMAND) {
	    int count = 0;

	    while (buffer.available() > 0) {

		count++;
		if (LOOP_COUNT_LIMIT > 0) {
		    if (count > LOOP_COUNT_LIMIT) {
			// break;
			output.write(content.toString());
			output.flush();
			throw new SDTByteBufferException(
				"Over LOOP_COUNT_LIMIT");
		    }
		}

		short command = buffer.getShort();
		if (1 <= command && command <= 41) {
		    if (command == 32 || command == 40) {
			content.append("!!!EXEC string command :");
			content.append(command);
			content.append('\n');
			// break;
			output.write(content.toString());
			output.flush();
			throw new SDTByteBufferException(
				"!!!EXEC string command :");
		    }
		    command_count_table[command]++;

		    int length = 0;
		    if (command == 32) {
			length = 0;
		    } else if (command == 40) {
			length = 0;
		    } else {
			length = SDTConsts.EXEC_SIZE[command];
		    }

		    buffer.setRpos(buffer.getRpos() + length - 2);

		    content.append("EXEC command : ");
		    content.append(command);
		    content.append(" [name]");
		    content.append(SDTConsts.EXEC_OPRS[command]);
		    content.append(" [next_pos]");
		    content.append(buffer.getRpos());
		    content.append(" [args_len]");
		    content.append(length - 2);
		    content.append('\n');
		} else if (64 <= command && command <= 297) {
		    content.append("ESC command : ");
		    content.append(command);
		    content.append(" [name]");
		    content.append(SDTConsts.ESC_NAMES[command - 64]);

		    command_count_table[command]++;

		    int length = getCommandLength(
			    SDTConsts.ESC_OPRS[command - 64], buffer, content);

		    content.append(" [next_pos]");
		    content.append(buffer.getRpos());
		    content.append(" [args_len]");
		    content.append(length);
		    content.append('\n');

		    /*
		     * if(length == -1) {
		     * content.append("!!!ESC string command :");
		     * content.append(command); content.append("=>");
		     * content.append(SDTConsts.ESC_NAMES[command - 64]);
		     * content.append('\n'); break; }
		     */
		} else {
		    content.append("!!!Unknown command :");
		    content.append(command);
		    content.append('\n');
		    break;
		}
	    }

	    content.append("commands count == ");
	    content.append(count);
	    content.append('\n');

	    content.append(SDTDump.SEPARATOR);
	    content.append('\n');
	}

	output.write(content.toString());
	output.flush();
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub
	System.out.println("SDTDump start...");

	String[] names = SDTDumpUtils.getFilesNames("./sdt/");
	// System.out.println(names[0]);

	int[] command_count_table = new int[300];

	for (int i = 0; i < names.length; i++) {
	    String input_name = "./sdt/" + names[i];
	    String output_name = "./out/" + names[i] + ".txt";
	    int ret = processSDT(input_name, output_name, command_count_table);
	    if (ret != 0) {
		System.out.println("!!!ERROR : " + input_name);
		break;
	    }
	}

	for (int i = 0; i < 300; i++) {
	    System.out.println(i + " => " + command_count_table[i]);
	}

	System.out.println("SDTDump end...");
    }

    public static int processSDT(String input_name, String output_name,
	    int[] command_count_table) {
	int ret = 0;
	File filein = null;
	File fileout = null;
	Writer output = null;
	InputStream input = null;
	SDTDump dumper = new SDTDump();
	try {
	    // 010301000.SDT
	    filein = new File(input_name);
	    fileout = new File(output_name);
	    // 字节流输入
	    input = new FileInputStream(filein);
	    // 字符流输出，UTF8
	    // 也可以用字节流，不过需要String.getBytes()转换
	    output = new FileWriter(fileout);
	    dumper.process(input, output, command_count_table);
	} catch (FileNotFoundException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	    ret = 1;
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	    ret = 2;
	} catch (SDTByteBufferException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	    ret = 3;
	} finally {
	    try {
		if (output != null)
		    output.close();
		if (input != null)
		    input.close();
	    } catch (IOException e) {
		e.printStackTrace();
	    }
	}
	return ret;
    }

    private static int getCommandLength(String type, SDTByteBuffer buffer,
	    StringBuilder content) throws SDTByteBufferException,
	    UnsupportedEncodingException {
	if (type.equals("0")) {
	    return 0;
	} else {
	    int ret = 0;
	    for (int i = 0; i < type.length(); i++) {
		// 缺1（ESC_ASC）和6（ESC_CMP）
		if (type.charAt(i) == '9' || type.charAt(i) == '8') {

		    content.append(" [arg-" + i + "]");
		    content.append(buffer.getShort());
		    // buffer.setRpos(buffer.getRpos() + 2);

		    ret += 2;
		} else if (type.charAt(i) == '2') {
		    byte mode = buffer.getByte();
		    ret += 1;
		    if (mode == 2) {
			byte len = buffer.getByte();

			content.append(" [arg-" + i + "]");
			byte[] buf = new byte[len];
			buffer.getRawBytes(buf);
			content.append(new String(buf, "shift-jis"));
			// buffer.setRpos(buffer.getRpos() + len);

			ret += len + 1;
		    } else {
			content.append(" [arg-" + i + "]");

			content.append(buffer.getInt());
			// buffer.setRpos(buffer.getRpos() + 4);

			ret += 4;
		    }
		} else if (type.charAt(i) == '5' || type.charAt(i) == '7') {
		    content.append(" [arg-" + i + "]");
		    content.append(buffer.getByte());
		    // buffer.setRpos(buffer.getRpos() + 1);
		    ret += 1;
		} else if (type.charAt(i) == '3') {
		    // ret = -1; //len + string
		    // break;
		    byte len = buffer.getByte();

		    content.append(" [arg-" + i + "]");
		    byte[] buf = new byte[len];
		    buffer.getRawBytes(buf);
		    content.append(new String(buf, "shift-jis"));
		    // buffer.setRpos(buffer.getRpos() + len);

		    ret += len + 1;
		} else if (type.charAt(i) == '4') {
		    // ret = -1; //2 * len + string
		    // break;
		    short len = buffer.getShort();

		    content.append(" [arg-" + i + "]");
		    byte[] buf = new byte[len];
		    buffer.getRawBytes(buf);
		    content.append(new String(buf, "shift-jis"));
		    // buffer.setRpos(buffer.getRpos() + len);

		    ret += len + 2;
		}
	    }
	    return ret;
	}
    }
}
