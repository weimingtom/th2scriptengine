package ugame.metamorphose.sdt;
public class SDTByteBufferException extends Exception {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * 
     * @param message
     */
    public SDTByteBufferException(final String message) {
	super(message);
    }
}
