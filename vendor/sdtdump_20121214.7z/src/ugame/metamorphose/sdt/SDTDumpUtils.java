package ugame.metamorphose.sdt;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SDTDumpUtils {
    private final static char[] DIGITS = { '0', '1', '2', '3', '4', '5', '6',
	    '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

    public static String getDateString() {
	final Date currentTime = new Date();
	final SimpleDateFormat formatter = new SimpleDateFormat(
		"yyyy-MM-dd HH:mm:ss", Locale.CHINA);
	return formatter.format(currentTime);
    }

    public static String getHexString(final byte[] array, final int offset,
	    final int len) {
	final StringBuilder sbuf = new StringBuilder();
	for (int i = 0; i < len; i++) {
	    final byte bval = array[offset + i];
	    if (i % 16 == 0 && i != 0) {
		sbuf.append('\n');
	    } else if (i % 16 != 0) {
		sbuf.append(' ');
	    }

	    if (i % 16 == 0) {
		sbuf.append("0x");
		sbuf.append(DIGITS[(i >> 32) & 0x0F]);
		sbuf.append(DIGITS[(i >> 28) & 0x0F]);
		sbuf.append(DIGITS[(i >> 24) & 0x0F]);
		sbuf.append(DIGITS[(i >> 20) & 0x0F]);
		sbuf.append(DIGITS[(i >> 16) & 0x0F]);
		sbuf.append(DIGITS[(i >> 12) & 0x0F]);
		sbuf.append(DIGITS[(i >> 8) & 0x0F]);
		sbuf.append(DIGITS[(i >> 4) & 0x0F]);
		sbuf.append(DIGITS[(i >> 0) & 0x0F]);
		sbuf.append(" : ");
	    }
	    sbuf.append(DIGITS[(bval >> 4) & 0x0F]);
	    sbuf.append(DIGITS[bval & 0x0F]);
	}
	return sbuf.toString();
    }

    public static String getHexString(final byte[] array) {
	return getHexString(array, 0, array.length);
    }

    public static String[] getFilesNames(String path) {
	File root = new File(path);
	File[] filesOrDirs = root.listFiles();
	int length = 0;
	for (int i = 0; i < filesOrDirs.length; i++) {
	    if (!filesOrDirs[i].isDirectory()) {
		length++;
	    }
	}
	String[] filesnames = new String[length];
	int index = 0;
	for (int i = 0; i < filesOrDirs.length; i++) {
	    if (!filesOrDirs[i].isDirectory()) {
		File file = filesOrDirs[i];
		filesnames[index] = file.getName();
		index++;
	    }
	}
	return filesnames;
    }
}
